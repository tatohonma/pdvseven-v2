﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("a7D.PDV.Integracao.WS2")]
[assembly: Guid("4dd61e28-9dc5-4cd2-a54b-fe4b7aca69cb")]
