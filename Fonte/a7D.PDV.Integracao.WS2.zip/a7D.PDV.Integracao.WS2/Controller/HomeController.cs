﻿using System.Web.Mvc;

namespace a7D.PDV.Integracao.WS2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
